


/*void eepromload(){
  for(x=0;x<indx;x++){
    eeprom_write(x, msg[x]);
    delay_ms(20);
  }
}*/


